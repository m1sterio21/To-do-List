import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const TodoItem = ({
  todo,
  toggleTodo,
  deleteTodo,
  updateTodo,
  editingId,
  setEditingId,
  theme,
  isNew
}) => {
  const [editedText, setEditedText] = useState(todo.text);
  const [removing, setRemoving] = useState(false);

  const isEditing = editingId === todo.id;

  const handleEdit = () => setEditingId(todo.id);
  const handleSave = () => {
    updateTodo(todo.id, editedText);
    setEditingId(null);
  };
  const handleCancel = () => {
    setEditedText(todo.text);
    setEditingId(null);
  };
  const handleDelete = () => {
    setRemoving(true);
    setTimeout(() => deleteTodo(todo.id), 400);
  };

  const textColor =
    theme === 'dark'
      ? todo.completed
        ? '#777'
        : '#f0f0f0'
      : todo.completed
      ? '#999'
      : '#333';

  return (
    <AnimatePresence>
      {!removing && (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -16 }}
          transition={{ duration: 0.3 }}
          className={`todo-item-wrapper sortable-transition ${isNew ? 'appearing' : ''}`}
        >
          {isEditing ? (
            <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
              <input
                className="todo-input"
                value={editedText}
                onChange={(e) => setEditedText(e.target.value)}
              />
              <button className="add-button" onClick={handleSave}>
                Сохранить
              </button>
              <button
                className="add-button"
                style={{ background: '#e5e7eb', color: '#333' }}
                onClick={handleCancel}
              >
                Отмена
              </button>
            </div>
          ) : (
            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center'
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <input
                  type="checkbox"
                  checked={todo.completed}
                  onChange={() => toggleTodo(todo.id)}
                />
                <span
                  style={{
                    textDecoration: todo.completed ? 'line-through' : 'none',
                    color: textColor
                  }}
                >
                  {todo.text}
                </span>
              </div>
              <div style={{ display: 'flex', gap: '8px' }}>
                <button className="add-button" onClick={handleEdit}>
                  Редактировать
                </button>
                <button
                  className="add-button"
                  style={{ background: '#ef4444' }}
                  onClick={handleDelete}
                >
                  Удалить
                </button>
              </div>
            </div>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default TodoItem;
