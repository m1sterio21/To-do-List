import React, { useState } from 'react';
import './styles.css';

const TodoForm = ({ addTodo }) => {
  const [value, setValue] = useState('');
  const [deadline, setDeadline] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (value.trim()) {
      addTodo(value, deadline);
      setValue('');
      setDeadline('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="todo-form">
      <input
        type="text"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="Что нужно сделать?"
        className="todo-input"
        required
      />
      <input
        type="date"
        value={deadline}
        onChange={(e) => setDeadline(e.target.value)}
        className="deadline-input"
      />
      <button type="submit" className="add-button">Добавить</button>
    </form>
  );
};

export default TodoForm;