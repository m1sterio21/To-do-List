import React from 'react';
import './styles.css';

const FilterButtons = ({ filter, setFilter, activeTodosCount, clearCompleted }) => {
  return (
    <div className="filter-buttons">
      <span className="filter-count">{activeTodosCount} задач осталось</span>

      <div className="filter-group">
        <button
          className={`add-button ${filter === 'all' ? '' : 'ghost-button'}`}
          onClick={() => setFilter('all')}
        >
          Все
        </button>
        <button
          className={`add-button ${filter === 'active' ? '' : 'ghost-button'}`}
          onClick={() => setFilter('active')}
        >
          Активные
        </button>
        <button
          className={`add-button ${filter === 'completed' ? '' : 'ghost-button'}`}
          onClick={() => setFilter('completed')}
        >
          Завершённые
        </button>
      </div>

      <button
        className="add-button clear-completed"
        onClick={clearCompleted}
      >
        Очистить выполненные
      </button>
    </div>
  );
};

export default FilterButtons;